package com.sheftech.otg;
import android.app.*; import android.os.*; import android.hardware.usb.*; import android.graphics.Color;
import android.view.*; import android.widget.*; import java.util.*;

public class MainActivity extends Activity {
 UsbManager usb; LinearLayout root; TextView status; final int gold=Color.rgb(255,200,0);
 public void onCreate(Bundle b){super.onCreate(b); usb=(UsbManager)getSystemService(USB_SERVICE); ui(); scan();}
 TextView t(String s,int n){TextView x=new TextView(this);x.setText(s);x.setTextSize(n);x.setTextColor(Color.WHITE);x.setPadding(0,10,0,10);return x;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.BLACK);b.setBackgroundColor(gold);b.setAllCaps(false);return b;}
 void ui(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,35,28,25);root.setBackgroundColor(Color.rgb(7,9,11));
 TextView h=t("SHEFTECH",34);h.setTextColor(gold);h.setTypeface(null,1);root.addView(h);root.addView(t("OTG Phone Repair Assistant",18));
 status=t("Checking USB connection…",16);root.addView(status);
 Button s=btn("🔎 Scan USB / OTG");s.setOnClickListener(v->scan());root.addView(s);
 Button d=btn("🛠 Run Diagnostics");d.setOnClickListener(v->info("Diagnostics","Shows USB devices visible to Android. It does not bypass screen locks or decrypt protected data."));root.addView(d);
 Button r=btn("🔐 Official Recovery Guide");r.setOnClickListener(v->info("Forgotten Password","There is no universal OTG password-bypass method. Use the manufacturer's official recovery/account process. A factory reset may erase protected data."));root.addView(r);
 setContentView(root);}
 void scan(){HashMap<String,UsbDevice> ds=usb.getDeviceList();if(ds.isEmpty()){status.setText("No USB device detected. Connect a phone through an OTG adapter.");return;}
 StringBuilder x=new StringBuilder("USB devices detected:\n");for(UsbDevice d:ds)x.append("• ").append(d.getDeviceName()).append("  VID ").append(d.getVendorId()).append(" / PID ").append(d.getProductId()).append("\n");status.setText(x.toString());}
 void info(String a,String b){new AlertDialog.Builder(this).setTitle(a).setMessage(b).setPositiveButton("OK",null).show();}
}
