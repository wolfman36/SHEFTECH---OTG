# SHEFTECH OTG Prototype
Starter Android Studio project for authorized USB/OTG diagnostics and official recovery guidance.
It intentionally does not bypass screen locks, defeat authentication, decrypt protected data, or exploit vulnerabilities.
Open in Android Studio, sync Gradle, then Build > Build APK(s).
